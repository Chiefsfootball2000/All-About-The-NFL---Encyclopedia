# All About the NFL — Encyclopedia

A Pen created on CodePen.

Original URL: [https://codepen.io/FootballGuy123/pen/xbOxrxL](https://codepen.io/FootballGuy123/pen/xbOxrxL).

EXPLAINS EVERYTHING ABOUT THE NFL